# Book Review App

This is a basic MVVM Book Review Android App using Java.